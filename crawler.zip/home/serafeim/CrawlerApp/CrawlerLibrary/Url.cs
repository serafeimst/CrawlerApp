namespace CrawlerLibrary;

public class Url
{
    public static string BankOfGreeceUrl =
        "https://www.bankofgreece.gr/statistika/xrhmatopistwtikes-agores/ekswtrapezika-epitokia";
}